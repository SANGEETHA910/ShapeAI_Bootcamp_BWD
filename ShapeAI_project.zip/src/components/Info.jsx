import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javascript and ReactJs</h1>
      <p>Web development bootcamp for 7 days</p>
    </div>
  );
}
export default Info;
